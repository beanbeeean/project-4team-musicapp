import React from "react";
import MainCharts from "../components/MainCharts";

const Home = () => {
  return (
    <div>
      <MainCharts />
    </div>
  );
};

export default Home;
